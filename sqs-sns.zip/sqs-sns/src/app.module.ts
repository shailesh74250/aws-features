import { MiddlewareConsumer, Module, RequestMethod } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { LoggerModule } from './shared/logger/logger.module';
import { UserModule } from './modules/user/user.module';
import { DatabaseModule } from './infrastructure/database/database.module';
import { ConfigModule } from '@nestjs/config';
import databaseConfig from './config/database.config';
import loggerConfig from './config/logger.config';
import { swaggerConfig } from './config/swagger.config';
import { JwtService } from './modules/auth/auth.service';
import { JwtController } from './modules/auth/auth.controller';
import { AwsModule } from './modules/aws/aws.module';

@Module({
  imports: [
    JwtModule.register({
      secret: process.env.SECRET_KEY || 'default-secret-key',
      signOptions: { expiresIn: '1h' }, // Token valid for 1 hour
    }),
    LoggerModule,
    DatabaseModule,
    UserModule,
    ConfigModule.forRoot({
      isGlobal: true,
      load: [swaggerConfig, databaseConfig, loggerConfig],
    }),
    AwsModule,
  ],
  controllers: [AppController,JwtController],
  providers: [AppService,JwtService],
  exports: [JwtService],
})
export class AppModule {}


