import {
    CallHandler,
    ExecutionContext,
    Injectable,
    NestInterceptor,
  } from '@nestjs/common';
  import { Observable } from 'rxjs';
  import { map } from 'rxjs/operators';
  import * as CryptoJS from 'crypto-js';
  
  const secretKey = process.env.SECRET_KEY || 'default-secret-key';
  
  @Injectable()
  export class EncryptionInterceptor implements NestInterceptor {
    intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
      return next.handle().pipe(
        map((data) => {
          const sanitizedData = Array.isArray(data)
            ? data.map((item) => this.removeTimestamps(item))
            : this.removeTimestamps(data);
          const encryptedPayload = CryptoJS.AES.encrypt(
            JSON.stringify(sanitizedData),
            secretKey,
          ).toString();
  
          return { payload: encryptedPayload };
        }),
      );
    }
  
    private removeTimestamps(data: any): any {
      if (!data) {
        return data; // Return as-is if data is undefined or null
      }
    
      const { createdAt, updatedAt, ...rest } = data; // Exclude `createdAt` and `updatedAt`
      return rest;
    }
  }
