// // // import {
// // //   Table,
// // //   Column,
// // //   Model,
// // //   DataType,
// // //   BeforeUpdate,
// // // } from 'sequelize-typescript';

// // // /**
// // //  * User database entity representing a user in the database.
// // //  *
// // //  * @class UserDbEntity
// // //  * @extends Model
// // //  */
// // // @Table({
// // //   tableName: 'users',
// // //   timestamps: true,
// // // })
// // // export class UserDbEntity extends Model<UserDbEntity> {
// // //   /**
// // //    * The unique identifier of the user.
// // //    *
// // //    * @column
// // //    * @type {string}
// // //    */
// // //   @Column({
// // //     type: DataType.BIGINT,
// // //     defaultValue: DataType.BIGINT,
// // //     primaryKey: true,
// // //   })
// // //   id: string | number;

// // //   /**
// // //    * The name of the user.
// // //    *
// // //    * @column
// // //    * @type {string}
// // //    */
// // //   @Column({
// // //     type: DataType.STRING,
// // //     allowNull: false,
// // //   })
// // //   name: string;

// // //   /**
// // //    * The email of the user.
// // //    *
// // //    * @column
// // //    * @type {string}
// // //    */
// // //   @Column({
// // //     type: DataType.STRING,
// // //     allowNull: false,
// // //     unique: true,
// // //   })
// // //   email: string;

// // //   /**
// // //    * The password of the user.
// // //    *
// // //    * @column
// // //    * @type {string}
// // //    */
// // //   @Column({
// // //     type: DataType.STRING,
// // //     allowNull: false,
// // //   })
// // //   password: string;

// // //   /**
// // //    * The date and time when the user was created.
// // //    *
// // //    * @column
// // //    * @type {Date}
// // //    */
// // //   @Column({
// // //     type: DataType.DATE,
// // //     defaultValue: DataType.NOW,
// // //   })
// // //   createdAt: Date;

// // //   /**
// // //    * The date and time when the user was last updated.
// // //    *
// // //    * @column
// // //    * @type {Date}
// // //    */
// // //   @Column({
// // //     type: DataType.DATE,
// // //     defaultValue: DataType.NOW,
// // //   })
// // //   updatedAt: Date;

// // //   /**
// // //    * Hook to update the updatedAt field before updating the record.
// // //    */
// // //   @BeforeUpdate
// // //   static updateTimestamp(instance: UserDbEntity) {
// // //     instance.updatedAt = new Date();
// // //   }
// // // }

// // // export default UserDbEntity;
// // import {
// //   Table,
// //   Column,
// //   Model,
// //   DataType,
// //   BeforeUpdate,
// // } from 'sequelize-typescript';

// // /**
// //  * User database entity representing a user in the database.
// //  *
// //  * @class UserDbEntity
// //  * @extends Model
// //  */
// // @Table({
// //   tableName: 'users',
// //   timestamps: true,
// // })
// // export class UserDbEntity extends Model<UserDbEntity> {
// //   /**
// //    * The unique identifier of the user.
// //    *
// //    * @column
// //    * @type {string}
// //    */
// //   @Column({
// //     type: DataType.BIGINT,
// //     autoIncrement: true, // Enable auto-increment for the primary key
// //     primaryKey: true,
// //   })
// //   id: string | number;

// //   /**
// //    * The name of the user.
// //    *
// //    * @column
// //    * @type {string}
// //    */
// //   @Column({
// //     type: DataType.STRING,
// //     allowNull: false,
// //   })
// //   name: string;

// //   /**
// //    * The email of the user.
// //    *
// //    * @column
// //    * @type {string}
// //    */
// //   @Column({
// //     type: DataType.STRING,
// //     allowNull: false,
// //     unique: true,
// //   })
// //   email: string;

// //   /**
// //    * The password of the user.
// //    *
// //    * @column
// //    * @type {string}
// //    */
// //   @Column({
// //     type: DataType.STRING,
// //     allowNull: false,
// //   })
// //   password: string;

// //   /**
// //    * The date and time when the user was created.
// //    *
// //    * @column
// //    * @type {Date}
// //    */
// //   @Column({
// //     type: DataType.DATE,
// //     defaultValue: DataType.NOW,
// //   })
// //   createdAt: Date;

// //   /**
// //    * The date and time when the user was last updated.
// //    *
// //    * @column
// //    * @type {Date}
// //    */
// //   @Column({
// //     type: DataType.DATE,
// //     defaultValue: DataType.NOW,
// //   })
// //   updatedAt: Date;

// //   /**
// //    * Hook to update the updatedAt field before updating the record.
// //    */
// //   @BeforeUpdate
// //   static updateTimestamp(instance: UserDbEntity) {
// //     instance.updatedAt = new Date();
// //   }
// // }

// // export default UserDbEntity;
// import {
//   Table,
//   Column,
//   Model,
//   DataType,
//   BeforeUpdate,
// } from 'sequelize-typescript';

// @Table({
//   tableName: 'users',
//   timestamps: true,
// })
// export class UserDbEntity extends Model<UserDbEntity> {
//   @Column({
//     type: DataType.BIGINT,
//     autoIncrement: true, // Enable auto-increment
//     primaryKey: true,
//   })
//   id: number;

//   @Column({
//     type: DataType.STRING,
//     allowNull: false,
//   })
//   name: string;

//   @Column({
//     type: DataType.STRING,
//     allowNull: false,
//     unique: true,
//   })
//   email: string;

//   @Column({
//     type: DataType.STRING,
//     allowNull: false,
//   })
//   password: string;

//   @Column({
//     type: DataType.DATE,
//     defaultValue: DataType.NOW,
//   })
//   createdAt: Date;

//   @Column({
//     type: DataType.DATE,
//     defaultValue: DataType.NOW,
//   })
//   updatedAt: Date;

//   @BeforeUpdate
//   static updateTimestamp(instance: UserDbEntity) {
//     instance.updatedAt = new Date();
//   }
// }
// filepath: /src/modules/user/infrastructure/database/sql/entities/user.db.entity.ts
import {
  Table,
  Column,
  Model,
  DataType,
  BeforeUpdate,
} from 'sequelize-typescript';

@Table({
  tableName: 'users',
  timestamps: true,
})
export class UserDbEntity extends Model<UserDbEntity> {
  @Column({
    type: DataType.BIGINT,
    autoIncrement: true,
    primaryKey: true,
  })
  id: number;

  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  name: string;

  @Column({
    type: DataType.STRING,
    allowNull: false,
    unique: true,
  })
  email: string;

  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  password: string;

  @Column({
    type: DataType.DATE,
    defaultValue: DataType.NOW,
  })
  createdAt: Date;

  @Column({
    type: DataType.DATE,
    defaultValue: DataType.NOW,
  })
  updatedAt: Date;

  @BeforeUpdate
  static updateTimestamp(instance: UserDbEntity) {
    instance.updatedAt = new Date();
  }
}

export default UserDbEntity; // Ensure this is the default export