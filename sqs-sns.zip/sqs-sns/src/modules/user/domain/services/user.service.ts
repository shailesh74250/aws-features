import { BadRequestException, Injectable, NotFoundException, Logger } from '@nestjs/common';
import { Inject } from '@nestjs/common';
import { IUserRepository } from '../../infrastructure/database/user.repository.interface';
import * as crypto from 'crypto';
import { QueryTypes } from 'sequelize';
import * as bcrypt from 'bcrypt';
import { CreateUserDto } from '../dto/create-user.dto';
import { UpdateUserDto } from '../dto/update-user.dto';
import { User } from '../entities/user.entity';
import Hashids from 'hashids';

// import { HashIdUtil } from 'src/utils/hashid.util';

/**
 * UserService handles all business logic related to users.
 *
 * @service UserService
 */
@Injectable()
export class UserService {
  private readonly salt = 'hash-salt'; // Use a secure, random salt

  private readonly logger = new Logger(UserService.name);

  constructor(
    @Inject('IUserRepository') private readonly userRepository: IUserRepository,
  ) {}

  @Inject('USER_MODEL') // Replace 'USER_MODEL' with the actual provider name for the user model
  private readonly userModel: any; // Replace 'any' with the actual type of the user model

  hashPassword(password: string): string {
    const hash = crypto.createHash('md5').update(password).digest('hex');
    return hash;
  }

  async createUser(userData: any) {
    const { password } = userData;

    // Hash the password using SHA-256
    const hashedPassword = this.hashPassword(password);

    // Save the user with the hashed password
    const user = await this.userRepository.createUser({
      ...userData,
      password: hashedPassword,
    });
    

    return user;
  }

  validatePassword(plainPassword: string, hashedPassword: string): boolean {
    const hashedPlainPassword = this.hashPassword(plainPassword);
    return hashedPlainPassword === hashedPassword;
  }
  /**
   * Retrieves all users.
   *
   * @returns An array of users
   */
 
async getAllUsers(): Promise<User[]> {
  const users = await this.userRepository.getAllUsers();
  
  if (!users || users.length === 0) {
    throw new NotFoundException('No users found');
  }
  
  // Create a new instance of Hashids
  const hashids = new Hashids('hash-salt', 5); // salt and min length
  
  const newUsers = users.map(user => {
    if (!user.id) {
      throw new BadRequestException(`User ID is missing for user: ${JSON.stringify(user)}`);
    }
    
    const hashid = hashids.encode(Number(user.id));
    return { ...user, id: hashid };
  });
  
  this.logger.log('Query Result:', newUsers);
  return newUsers;
}
  /**
   * Retrieves a user by ID.
   *
   * @param id - The ID of the user to retrieve
   * @returns The user with the specified ID
   * @throws NotFoundException if the user is not found
   */
 
  async getUserById(id: string): Promise<User> {
    const query = `
      SELECT decode_from_hashid('Yl535zYOnm') AS hashid;
    `;
    this.logger.log('Query:', query);
    this.logger.log('Parameters:', id);
  
    const result = await this.userRepository.query(query, [id]);
  
    if ((result as any[]).length === 0) {
      throw new NotFoundException(`User with ID ${id} not found`);
    }
  
    // Convert BigInt to string if necessary
    const resultArray = result as { hashid: string | bigint }[];
    const hashid: string | bigint = resultArray[0].hashid;
    const userId = typeof hashid === 'bigint' ? hashid.toString() : hashid;
    this.logger.log('Decoded ID:', userId);
    // Fetch the user by numeric ID
  
    const user = await this.userRepository.getUserById(userId);
    if (!user) {
      throw new NotFoundException(`User with ID ${id} not found`);
    }
    return {...user, id: id};
  }
  
  /**
   * Updates a user by ID.
   *
   * @param id - The ID of the user to update
   * @param updateUserDto - Data Transfer Object for updating a user
   * @returns The updated user
   * @throws NotFoundException if the user is not found
   */
  async updateUser(id: string, updateUserDto: UpdateUserDto): Promise<User> {
    const user = await this.userRepository.updateUser(id, updateUserDto);
    if (!user) {
      throw new NotFoundException(`User with ID ${id} not found`);
    }
    return user;
  }

  /**
   * Deletes a user by ID.
   *
   * @param id - The ID of the user to delete
   * @throws NotFoundException if the user is not found
   */
  async deleteUser(id: string): Promise<void> {
    await this.userRepository.deleteUser(id);
  }
}
