import {
  Controller,
  Post,
  Get,
  Body,
  Headers,
  UnauthorizedException,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
} from '@nestjs/swagger';
import { JwtService } from './auth.service';

@ApiTags('JWT')
@Controller('jwt')
export class JwtController {
  constructor(private readonly jwtService: JwtService) {}

  @ApiOperation({ summary: 'Generate a JWT token' })
  @ApiResponse({ status: 201, description: 'JWT token generated successfully' })
  @Post('generate')
  generateToken(@Body() payload: any): { token: string } {
    const token = this.jwtService.generateToken(payload);
    return { token };
  }

  @Get('validate')
  @ApiOperation({ summary: 'Validate a JWT token' })
  @ApiResponse({ status: 200, description: 'Token is valid' })
  @ApiResponse({ status: 401, description: 'Token is invalid or expired' })
  validateToken(@Headers('authorization') authHeader: string): any {
    try {
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        throw new UnauthorizedException('Token must be provided in Authorization header');
      }

      const token = authHeader.split(' ')[1]; // Extract the JWT
      return this.jwtService.validateToken(token);
    } catch (error) {
      throw new UnauthorizedException(error.message);
    }
  }
}
