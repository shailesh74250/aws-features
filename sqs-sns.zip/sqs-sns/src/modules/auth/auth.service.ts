import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService as NestJwtService } from '@nestjs/jwt';
import * as crypto from 'crypto';
import { LoggerService } from '../../shared/logger/logger.service';

@Injectable()
export class JwtService {
  private readonly symmetricKey: Buffer;
  private readonly algorithm = 'aes-256-cbc';
  private readonly ivLength = 16;

  constructor(
    private readonly jwtService: NestJwtService,
    private readonly logger: LoggerService,
  ) {
    const keyFromEnv = process.env.SECRET_KEY || 'default-secret-key';
    this.symmetricKey = crypto.createHash('sha256').update(keyFromEnv).digest();
  }

  generateToken(payload: any): string {
    const timestamp = new Date().toISOString();
    const encryptedTimestamp = this.encryptTimestamp(timestamp);

    const claims = { ...payload, encryptedTimestamp };
    const token = this.jwtService.sign(claims, { expiresIn: '1h' });

    this.logger.info(`Generated Token: ${token}`, 'JwtService');
    return token;
  }

  validateToken(token: string): any {
    try {
      this.logger.info(`Token Received for Validation: ${token}`, 'JwtService');

      const decoded = this.jwtService.verify(token);
      this.logger.debug(`Decoded Token: ${JSON.stringify(decoded)}`, 'JwtService');

      if (!decoded.encryptedTimestamp) {
        throw new UnauthorizedException('Missing timestamp');
      }

      const decryptedTimestamp = this.decryptTimestamp(decoded.encryptedTimestamp);
      this.logger.debug(`Decrypted Timestamp: ${decryptedTimestamp}`, 'JwtService');

      if (!this.isTimestampValid(decryptedTimestamp)) {
        throw new UnauthorizedException('Token timestamp is expired (more than 30 seconds)');
      }

      return {
        message: 'Token is valid within 30s window',
        payload: decoded,
      };
    } catch (error) {
      this.logger.error(`Invalid token: ${error.message}`, error.stack, 'JwtService');
      throw new UnauthorizedException(`Invalid token: ${error.message}`);
    }
  }

  private encryptTimestamp(timestamp: string): string {
    const iv = crypto.randomBytes(this.ivLength);
    const cipher = crypto.createCipheriv(this.algorithm, this.symmetricKey, iv);
    let encrypted = cipher.update(timestamp, 'utf8', 'base64');
    encrypted += cipher.final('base64');
    return `${iv.toString('base64')}:${encrypted}`;
  }

  private decryptTimestamp(encryptedTimestamp: string): string {
    const [iv, encrypted] = encryptedTimestamp.split(':');
    if (!iv || !encrypted) {
      throw new Error('Invalid timestamp format');
    }
    const decipher = crypto.createDecipheriv(
      this.algorithm,
      this.symmetricKey,
      Buffer.from(iv, 'base64'),
    );
    let decrypted = decipher.update(encrypted, 'base64', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  }

  private isTimestampValid(timestamp: string): boolean {
    const now = new Date();
    const tokenTime = new Date(timestamp);
    const diff = Math.abs(now.getTime() - tokenTime.getTime());

    this.logger.debug(`Time difference (ms): ${diff}`, 'JwtService');
    return diff < 30 * 1000; // 30 seconds
  }
}