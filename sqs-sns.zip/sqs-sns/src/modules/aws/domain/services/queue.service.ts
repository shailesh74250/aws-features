import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as AWS from 'aws-sdk';

@Injectable()
export class QueueService {
  private sqs: AWS.SQS;

  private readonly logger = new Logger(QueueService.name);

  constructor(private readonly configService: ConfigService) {
    AWS.config.update({
      accessKeyId: this.configService.get<string>('AWS_ACCESS_KEY_ID'),
      secretAccessKey: this.configService.get<string>('AWS_SECRET_ACCESS_KEY'),
      region: this.configService.get<string>('AWS_REGION'),
    });

    this.sqs = new AWS.SQS();
  }

  async createQueue(queueName: string): Promise<AWS.SQS.CreateQueueResult> {
    const params: AWS.SQS.CreateQueueRequest = {
      QueueName: queueName,
    };
    return this.sqs.createQueue(params).promise();
  }

  async deleteQueue(queueUrl: string): Promise<void> {
    const params: AWS.SQS.DeleteQueueRequest = {
      QueueUrl: queueUrl,
    };
    await this.sqs.deleteQueue(params).promise();
  }
  async getQueueAttributes(queueUrl: string): Promise<AWS.SQS.GetQueueAttributesResult> {
    const params: AWS.SQS.GetQueueAttributesRequest = {
      QueueUrl: queueUrl,
      AttributeNames: ['All'],
    };
    return this.sqs.getQueueAttributes(params).promise();
  }
  async getOrCreateQueueUrl(queueName: string): Promise<string> {
    try {
      
      const params: AWS.SQS.GetQueueUrlRequest = {
        QueueName: queueName,
      };
      const result = await this.sqs.getQueueUrl(params).promise();
      this.logger.log(`Queue URL fetched: ${result.QueueUrl}`);
      return result.QueueUrl!;
    } catch (error) {
      if (error.code === 'AWS.SimpleQueueService.NonExistentQueue') {

        this.logger.log(`Queue does not exist. Creating queue: ${queueName}`);
        const createParams: AWS.SQS.CreateQueueRequest = {
          QueueName: queueName,
        };
        const createResult = await this.sqs.createQueue(createParams).promise();
        this.logger.log(`Queue created with URL: ${createResult.QueueUrl}`);
        return createResult.QueueUrl!;
      }
      throw error;
    }
  }
}
