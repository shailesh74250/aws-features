import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as AWS from 'aws-sdk';
import { QueueService } from './queue.service';

@Injectable()
export class MessageService {
  private sqs: AWS.SQS;

  constructor(
    private readonly configService: ConfigService,
    private readonly queueService: QueueService, // Inject QueueService
  ) {
    AWS.config.update({
      accessKeyId: this.configService.get<string>('AWS_ACCESS_KEY_ID'),
      secretAccessKey: this.configService.get<string>('AWS_SECRET_ACCESS_KEY'),
      region: this.configService.get<string>('AWS_REGION'),
    });

    this.sqs = new AWS.SQS();
  }

  async sendMessage(queueName: string, messageBody: string): Promise<AWS.SQS.SendMessageResult> {
    const queueUrl = await this.queueService.getOrCreateQueueUrl(queueName); // Dynamically get or create queue
    const params: AWS.SQS.SendMessageRequest = {
      QueueUrl: queueUrl,
      MessageBody: messageBody,
    };
    return this.sqs.sendMessage(params).promise();
  }

  async receiveMessages(queueName: string): Promise<AWS.SQS.ReceiveMessageResult> {
    if (!queueName) {
      throw new Error('queueName is required');
    }
  
    const queueUrl = await this.queueService.getOrCreateQueueUrl(queueName); // Dynamically fetch QueueUrl
    const params: AWS.SQS.ReceiveMessageRequest = {
      QueueUrl: queueUrl,
      MaxNumberOfMessages: 10,
      WaitTimeSeconds: 10,
    };
  
    return this.sqs.receiveMessage(params).promise();
  }
  
  async fetchAndDeleteMessage(queueName: string): Promise<{ messageId: string; status: string }> {
    const queueUrl = await this.queueService.getOrCreateQueueUrl(queueName); // Dynamically fetch QueueUrl
  
    const params: AWS.SQS.ReceiveMessageRequest = {
      QueueUrl: queueUrl,
      MaxNumberOfMessages: 1, 
      WaitTimeSeconds: 10,
    };
  
    const messages = await this.sqs.receiveMessage(params).promise();
  
    if (!messages.Messages || messages.Messages.length === 0) {
      throw new Error('No messages available to delete.');
    }
  
    const message = messages.Messages[0];
    const receiptHandle = message.ReceiptHandle;
  
    if (!receiptHandle) {
      throw new Error('ReceiptHandle is missing for the fetched message.');
    }
      const deleteParams: AWS.SQS.DeleteMessageRequest = {
      QueueUrl: queueUrl,
      ReceiptHandle: receiptHandle,
    };
  
    await this.sqs.deleteMessage(deleteParams).promise();
  
    return {
      messageId: message.MessageId!,
      status: 'Deleted',
    };
  }
  async purgeQueue(queueName: string): Promise<void> {
    const queueUrl = await this.queueService.getOrCreateQueueUrl(queueName); // Dynamically get or create queue
    const params: AWS.SQS.PurgeQueueRequest = {
      QueueUrl: queueUrl,
    };
    await this.sqs.purgeQueue(params).promise();
  }
}
