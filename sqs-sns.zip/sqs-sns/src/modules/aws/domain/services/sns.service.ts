import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as AWS from 'aws-sdk';

@Injectable()
export class SnsService {
  private sns: AWS.SNS;

  constructor(private readonly configService: ConfigService) {
    AWS.config.update({
      accessKeyId: this.configService.get<string>('AWS_ACCESS_KEY_ID'),
      secretAccessKey: this.configService.get<string>('AWS_SECRET_ACCESS_KEY'),
      region: this.configService.get<string>('AWS_REGION'),
    });

    this.sns = new AWS.SNS();
  }

  // Create a topic
  async createTopic(topicName: string): Promise<AWS.SNS.CreateTopicResponse> {
    const params: AWS.SNS.CreateTopicInput = {
      Name: topicName,
    };
    return this.sns.createTopic(params).promise();
  }

  // Subscribe to a topic
  async subscribe(
    topicArn: string,
    protocol: string,
    endpoint: string,
  ): Promise<AWS.SNS.SubscribeResponse> {
    const params: AWS.SNS.SubscribeInput = {
      TopicArn: topicArn,
      Protocol: protocol,
      Endpoint: endpoint,
    };
    return this.sns.subscribe(params).promise();
  }

  // Publish a message to a topic
  async publish(
    topicArn: string,
    message: string,
    subject?: string,
  ): Promise<AWS.SNS.PublishResponse> {
    const params: AWS.SNS.PublishInput = {
      TopicArn: topicArn,
      Message: message,
      Subject: subject,
    };
    return this.sns.publish(params).promise();
  }

  // Send SMS message
  async sendSms(phoneNumber: string, message: string): Promise<AWS.SNS.PublishResponse> {
    const params: AWS.SNS.PublishInput = {
      PhoneNumber: phoneNumber,
      Message: message,
    };
    return this.sns.publish(params).promise();
  }

  // Send push notification
  async sendPushNotification(
    platformEndpointArn: string,
    message: string,
    title?: string,
  ): Promise<AWS.SNS.PublishResponse> {
    const payload = {
      default: message,
      APNS: JSON.stringify({
        aps: {
          alert: {
            title: title || 'Notification',
            body: message,
          },
          sound: 'default',
        },
      }),
      GCM: JSON.stringify({
        notification: {
          title: title || 'Notification',
          body: message,
        },
      }),
    };

    const params: AWS.SNS.PublishInput = {
      TargetArn: platformEndpointArn,
      Message: JSON.stringify(payload),
      MessageStructure: 'json',
    };

    return this.sns.publish(params).promise();
  }


  async deleteTopic(topicArn: string): Promise<void> {
    const subscriptions = await this.sns
      .listSubscriptionsByTopic({ TopicArn: topicArn })
      .promise();
    if (subscriptions.Subscriptions) {
      for (const subscription of subscriptions.Subscriptions) {
        if (subscription.SubscriptionArn !== 'PendingConfirmation') {
          await this.sns
            .unsubscribe({ SubscriptionArn: subscription.SubscriptionArn! })
            .promise();
        }
      }
    }
  
    await this.sns.deleteTopic({ TopicArn: topicArn }).promise();
  }

  async listTopics(): Promise<AWS.SNS.ListTopicsResponse> {
    return this.sns.listTopics().promise();
  }
}