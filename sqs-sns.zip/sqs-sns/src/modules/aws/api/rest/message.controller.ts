import { Controller, Post, Get, Delete, Body, Query } from '@nestjs/common';
import { MessageService } from '../../domain/services/message.service';

@Controller('message')
export class MessageController {
  constructor(private readonly messageService: MessageService) {}

  @Post('send')
async sendMessage(@Body('queueName') queueName: string, @Body('messageBody') messageBody: string) {
  if (!queueName || !messageBody) {
    throw new Error('Both queueName and messageBody are required in the request body');
  }
  return this.messageService.sendMessage(queueName, messageBody);
}
@Get('receive')
async receiveMessages(@Query('queueName') queueName: string) {
  if (!queueName) {
    throw new Error('queueName is required in the query parameter');
  }
  return this.messageService.receiveMessages(queueName);
}
  
@Delete('purge')
async purgeQueue(@Body('queueName') queueName: string) {
  if (!queueName) {
    throw new Error('queueName is required in the request body');
  }
  return this.messageService.purgeQueue(queueName);
}
  @Get('fetch-and-delete')
async fetchAndDeleteMessage(@Query('queueName') queueName: string) {
  if (!queueName) {
    throw new Error('queueName is required in the query parameter');
  }
  return this.messageService.fetchAndDeleteMessage(queueName);
}
}