import { Controller, Post, Delete, Get, Body, Query } from '@nestjs/common';
import { QueueService } from '../../domain/services/queue.service';

@Controller('queue')
export class QueueController {
  constructor(private readonly queueService: QueueService) {}

  @Post('create')
  async createQueue(@Body('queueName') queueName: string) {
    return this.queueService.createQueue(queueName);
  }

  @Delete('delete')
  async deleteQueue(@Body('queueUrl') queueUrl: string) {
    if (!queueUrl) {
      throw new Error('Queue URL is required in the request body');
    }
    return this.queueService.deleteQueue(queueUrl);
  }
  @Get('attributes')
  async getQueueAttributes(@Body('queueUrl') queueUrl: string) {
    return this.queueService.getQueueAttributes(queueUrl);
  }
}