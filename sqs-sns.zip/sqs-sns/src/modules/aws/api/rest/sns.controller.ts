import { Controller, Post, Get, Delete, Body, Query } from '@nestjs/common';
import { SnsService } from '../../domain/services/sns.service';

@Controller('sns')
export class SnsController {
  constructor(private readonly snsService: SnsService) {}

  @Post('create-topic')
  async createTopic(@Body('topicName') topicName: string) {
    if (!topicName) {
      throw new Error('topicName is required in the request body');
    }
    return this.snsService.createTopic(topicName);
  }

  @Post('subscribe')
  async subscribe(
    @Body('topicArn') topicArn: string,
    @Body('protocol') protocol: string,
    @Body('endpoint') endpoint: string,
  ) {
    if (!topicArn || !protocol || !endpoint) {
      throw new Error(
        'topicArn, protocol, and endpoint are required in the request body',
      );
    }
    return this.snsService.subscribe(topicArn, protocol, endpoint);
  }

  @Post('publish')
  async publish(
    @Body('topicArn') topicArn: string,
    @Body('message') message: string,
    @Body('subject') subject?: string,
  ) {
    if (!topicArn || !message) {
      throw new Error('topicArn and message are required in the request body');
    }
    return this.snsService.publish(topicArn, message, subject);
  }
  @Post('send-sms')
  async sendSms(
    @Body('phoneNumber') phoneNumber: string,
    @Body('message') message: string,
  ) {
    if (!phoneNumber || !message) {
      throw new Error('phoneNumber and message are required in the request body');
    }
    return this.snsService.sendSms(phoneNumber, message);
  }

  @Post('send-push-notification')
  async sendPushNotification(
    @Body('platformEndpointArn') platformEndpointArn: string,
    @Body('message') message: string,
    @Body('title') title?: string,
  ) {
    if (!platformEndpointArn || !message) {
      throw new Error(
        'platformEndpointArn and message are required in the request body',
      );
    }
    return this.snsService.sendPushNotification(platformEndpointArn, message, title);
  }

  @Delete('delete-topic')
  async deleteTopic(@Query('topicArn') topicArn: string) {
    if (!topicArn) {
      throw new Error('topicArn is required in the query parameter');
    }
    return this.snsService.deleteTopic(topicArn);
  }

  @Get('list-topics')
  async listTopics() {
    return this.snsService.listTopics();
  }
}