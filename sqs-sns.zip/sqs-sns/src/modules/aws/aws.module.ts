import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { QueueService } from './domain/services/queue.service';
import { QueueController } from './api/rest/queue.controller';
import { MessageService } from './domain/services/message.service';
import { MessageController } from './api/rest/message.controller';
import { SnsService } from './domain/services/sns.service';
import { SnsController } from './api/rest/sns.controller';


@Module({
  imports: [ConfigModule],
  providers: [QueueService, MessageService, SnsService],
  controllers: [QueueController, MessageController, SnsController],
  exports: [QueueService, MessageService, SnsService],
})
export class AwsModule {}