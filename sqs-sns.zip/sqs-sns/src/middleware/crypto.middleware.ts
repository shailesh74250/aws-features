import { Request, Response, NextFunction } from 'express';
import * as CryptoJS from 'crypto-js';
import { LoggerService } from '../shared/logger/logger.service';

const secretKey = process.env.SECRET_KEY || 'default-secret-key';

export function CryptoMiddleware(logger: LoggerService) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (req.body && req.body.payload) {
      logger.log('Encrypted Payload Received', 'CryptoMiddleware');
    } else {
      logger.error('No payload in the request body', '', 'CryptoMiddleware');
    }

    if (req.body?.payload) {
      try {
        const bytes = CryptoJS.AES.decrypt(req.body.payload, secretKey);
const decrypted = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
        logger.log('Decrypted Data (Backend): ' + JSON.stringify(decrypted), 'CryptoMiddleware');
        req.body = decrypted;
      } catch (error) {
        logger.error('Decryption failed: ' + error.message, '', 'CryptoMiddleware');
      }
    }
    next();
  };
}